const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

// 配置
const PORT = 8080;
const HOST = '0.0.0.0';

// MIME类型映射
const mimeTypes = {
  '.html': 'text/html',
  '.js': 'application/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.eot': 'application/vnd.ms-fontobject'
};

// 获取MIME类型
function getMimeType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  return mimeTypes[ext] || 'application/octet-stream';
}

// 检查文件是否存在
function fileExists(filePath) {
  try {
    return fs.statSync(filePath).isFile();
  } catch (err) {
    return false;
  }
}

// 创建HTTP服务器
const server = http.createServer((req, res) => {
  // 解析URL
  const parsedUrl = url.parse(req.url);
  let pathname = parsedUrl.pathname;
  
  // 记录请求
  console.log(`${new Date().toLocaleString()} - ${req.method} ${pathname}`);
  
  // 处理根路径
  if (pathname === '/') {
    pathname = '/index.html';
  }
  
  // 构建文件路径
  const filePath = path.join(__dirname, pathname);
  
  // 安全检查：防止目录遍历攻击
  if (!filePath.startsWith(__dirname)) {
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    res.end('403 Forbidden');
    return;
  }
  
  // 检查文件是否存在
  if (!fileExists(filePath)) {
    // 对于SPA应用，如果文件不存在，返回index.html
    const indexPath = path.join(__dirname, 'index.html');
    if (fileExists(indexPath)) {
      fs.readFile(indexPath, (err, data) => {
        if (err) {
          res.writeHead(500, { 'Content-Type': 'text/plain' });
          res.end('500 Internal Server Error');
          return;
        }
        
        res.writeHead(200, { 
          'Content-Type': 'text/html',
          'Cache-Control': 'no-cache'
        });
        res.end(data);
      });
    } else {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('404 Not Found');
    }
    return;
  }
  
  // 读取并返回文件
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('500 Internal Server Error');
      return;
    }
    
    const mimeType = getMimeType(filePath);
    const headers = {
      'Content-Type': mimeType,
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    };
    
    // 设置缓存策略
    if (mimeType.startsWith('text/') || mimeType === 'application/javascript') {
      headers['Cache-Control'] = 'no-cache';
    } else {
      headers['Cache-Control'] = 'public, max-age=86400'; // 1天
    }
    
    res.writeHead(200, headers);
    res.end(data);
  });
});

// 启动服务器
server.listen(PORT, HOST, () => {
  console.log('=================================');
  console.log('DMS-QA 前端静态服务器');
  console.log('=================================');
  console.log(`🚀 服务器已启动`);
  console.log(`📍 地址: http://${HOST}:${PORT}`);
  console.log(`📍 本地访问: http://localhost:${PORT}`);
  console.log(`📍 远程访问: http://192.168.1.57:${PORT}`);
  console.log(`📁 根目录: ${__dirname}`);
  console.log(`🕐 启动时间: ${new Date().toLocaleString()}`);
  console.log('=================================');
  console.log('按 Ctrl+C 停止服务器');
  console.log();
});

// 错误处理
server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`❌ 端口 ${PORT} 已被占用`);
    console.error('请检查是否有其他服务在使用此端口');
    console.error('或修改 PORT 变量使用其他端口');
  } else {
    console.error('❌ 服务器启动失败:', err.message);
  }
  process.exit(1);
});

// 优雅关闭
process.on('SIGINT', () => {
  console.log('\n🛑 正在关闭服务器...');
  server.close(() => {
    console.log('✅ 服务器已关闭');
    process.exit(0);
  });
});

process.on('SIGTERM', () => {
  console.log('\n🛑 收到终止信号，正在关闭服务器...');
  server.close(() => {
    console.log('✅ 服务器已关闭');
    process.exit(0);
  });
});
